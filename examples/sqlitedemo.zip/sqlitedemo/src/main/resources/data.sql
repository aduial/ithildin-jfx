INSERT INTO PERSON(name,message) values("Knerpje","oh gruttegruttemie nog an toe");
INSERT INTO PERSON(name,message) values("Fifi","Wadratjemienoe!");