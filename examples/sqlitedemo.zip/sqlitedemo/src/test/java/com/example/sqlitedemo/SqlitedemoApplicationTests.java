package com.example.sqlitedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqlitedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
